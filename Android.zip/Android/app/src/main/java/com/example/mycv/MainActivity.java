package com.example.mycv;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {
    private WebView wvCv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wvCv = findViewById(R.id.wv_cv);

        String urlFile = "file:///android_res/raw/cv.html";
        wvCv.loadUrl(urlFile);
    }
}